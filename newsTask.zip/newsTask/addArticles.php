<?php

include 'templet/header.php';
include 'config.php';
include 'include/function.php';
if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $title = $_POST['title'];
    $img = $_POST['img'];
    $dec =$_POST['description'];
    $category = $_POST['category'];
    // $chr = trim($img,'.PNG .GIF');
    // echo $chr;
    // $arrimg = array('.GIF','.PNG');
    // && in_array($arrimg  , $chr)
     if(empty($title) ){
     
       header('location:addArticles.php');
     }else{
     insertarticle('artical',$title,$img,$dec,$category);
     header('location:articles.php');
     }
    
  }
?>
<div class="container">
    <h1>Add Articles</h1>
<form action="" method='POST'>
  <div class="mb-3">
    
    <input type="text" class="form-control" id="title" name='title' >
    <label for="title" class="form-label">Article Title</label>
 
  </div>
  <div class="mb-3">
  <label for="title">Article image</label>
    <input type="file"  id="title" name='img'>
  </div>
  <div class="mb-3">
    
  <textarea class="form-control" placeholder="" name='description' id="article_description" ></textarea>
    <label for="article_description" class="form-label" >Article Description</label>
 
  </div>
  <div class="mb-3">
  <label for="title">Category</label>
  <select  class="form-control" name="category">   
<?php 
 foreach(fetchData('category') as $val){
 echo' <option value="'.$val['cate_id'].'">'.$val['name_category'].'</option>';}
  ?>
    </select>
  </div>

  <button type="submit" class="btn btn-primary">Submit</button>
</form>
</div>
<?php
include 'templet/footer.php';

?>