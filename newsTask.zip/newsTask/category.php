<?php
include 'templet/header.php';
include 'config.php';
include 'include/function.php';

?>
<div class="container">
    <h1 class="text-center">Category</h1>
    <div class="addcate">
    <a href="addCategory.php" class="btn btn-primary">Add Category</a>
    </div>
    <div class="row">
<?php 

 foreach(fetchData('category') as $val){
 
 echo '
  <div class="col-sm-6 col-lg-3 ">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">'.$val['name_category'].'</h5>
        <p class="card-text">250 Artical</p>
        <button type="button" class="btn btn-secondary">Edit</button>
        <a href="delete.php?id='.$val['cate_id'].' " class="btn btn-danger">Delete</a>
      </div>
    </div>
  </div>

';}
?>
</div>
</div>
<?php
include 'templet/footer.php';

?>