<?php
include 'templet/header.php';
include 'templet/navbar.php';
?>

<?php
include 'templet/footer.php';

  
?>