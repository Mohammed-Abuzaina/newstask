<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">
    <link rel="stylesheet" href="style.css">
    <title>Document</title>
</head>

<body>
    <nav>
        <div id="logo-menu">
            <div class="content">
                <ul>
                    <li class="logo">
                        <a href="#">
                            <img src="https://static.bbci.co.uk/frameworks/barlesque/2.83.4/orb/4/img/bbc-blocks-dark.png"
                                alt="BBC">
                        </a>
                    </li>
                    <li class="sign-in">
                        <a class="underlined" href="#">
                            <img src="https://static.bbci.co.uk/id/0.27.15/img/bbcid_orb_signin_dark.png" alt="Profile">
                            <span>Sign in</span>
                        </a>
                    </li>
                    <li><a class="underlined" href="#">News</a></li>
                    <li><a class="underlined" href="#">Sport</a></li>
                    <li><a class="underlined" href="#">Weather</a></li>
                    <li><a class="underlined" href="#">iPlayer</a></li>
                    <li><a class="underlined" href="#">TV</a></li>
                    <li><a class="underlined" href="#">Radio</a></li>
                    <li><a class="underlined" href="#">More</a></li>
                    <li class="search">
                        <div class="search-container">
                            <input type="text" placeholder="Search">
                            <a class="search-button" href="#">
                                <img src="https://static.bbci.co.uk/frameworks/barlesque/2.83.4/orb/4/img/orb-search-dark.png"
                                    alt="Search">
                            </a>
                        </div>
                    </li>
                </ul>
            </div>
        </div>

        <div class="red-header">
            <div id="department">
                <div class="content">
                    <a href="#">
                        <h1>News</h1>
                    </a>
                    <div id="find-local">
                        <a href="#">
                            <p>Find local news</p>
                        </a>
                    </div>
                </div>
            </div>

            <div id="primary-nav">
                <div class="content">
                    <ul>
                        <li><a class="underlined active" href="#"><span>Home</span></a></li>
                        <li><a class="underlined" href="#">UK</a></li>
                        <li><a class="underlined" href="#">World</a></li>
                        <li><a class="underlined" href="#">Business</a></li>
                        <li><a class="underlined" href="#">Tech</a></li>
                        <li><a class="underlined" href="#">Science</a></li>
                        <li><a class="underlined" href="#">Health</a></li>
                        <li><a class="underlined" href="#">Education</a></li>
                        <li><a class="underlined" href="#">Entertainment &amp; Arts</a></li>
                        <li><a class="underlined" href="#">Video &amp; Audio</a></li>
                        <li><a class="underlined" href="#">More</a></li>
                    </ul>
                </div>
            </div>
        </div>

        <div id="sub-nav">
            <div class="content">
                <ul>
                    <li><a class="underlined" href="#">England</a></li>
                    <li><a class="underlined" href="#">N. Ireland</a></li>
                    <li><a class="underlined" href="#">Scotland</a></li>
                    <li><a class="underlined" href="#">Alba</a></li>
                    <li><a class="underlined" href="#">Wales</a></li>
                    <li><a class="underlined" href="#">Cymru</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <main>
        <div class="content">
            <div class="main-content">
                <article class="full-width">
                    <a href="#">
                        <h2>Headline</h2>
                        <img class="article-image" src="//placehold.it/400x220" alt="Article image">
                        <p>Related headline article text. Some more text so you can see what it looks like with multiple
                            lines.</p>
                        <p>Even a new paragraph.</p>
                    </a>
                    <p class="post-data">Time posted<a class="country" href="#">Country</a></p>
                    <ul class="related-links">
                        <li><a href="#">
                                <div class="icon video"></div>Video Content 1
                            </a></li>
                        <li><a href="#">
                                <div class="icon video"></div>Video Content 2
                            </a></li>
                        <li><a href="#">Normal Content 1</a></li>
                        <li><a href="#">Normal Content 2</a></li>
                    </ul>
                </article>
            </div>
            <!--
    -->
            <div class="sidebar">
                <h2>Watch/Listen</h2>
                <article>
                    <a href="#">
                        <div class="image">
                            <img src="//placehold.it/105x60" alt="Article image">
                            <div class="time">4:52</div>
                        </div>
                        <h3>Article title</h3>
                        <p class="post-data">Time posted</p>
                    </a>
                </article>
                <article>
                    <a href="#">
                        <div class="image">
                            <img src="//placehold.it/105x60" alt="Article image">
                            <div class="time">1:19</div>
                        </div>
                        <h3><span class="tag sport">Tag</span>Article title</h3>
                        <p class="post-data">Time posted</p>
                    </a>
                </article>
                <article>
                    <a href="#">
                        <div class="image">
                            <img src="//placehold.it/105x60" alt="Article image">
                            <div class="time">0:36</div>
                        </div>
                        <h3>Article title</h3>
                        <p class="post-data">Time posted</p>
                    </a>
                </article>
            </div>
        </div>
    </main>




    <div class="card mb-3" style="width:50%;">
        <img class="card-img-top" src="./images/bg-title-01.jpg" alt=" Card image cap">
        <div class="card-body">
            <h5 class="card-title">Card title</h5>
            <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional
                content. This content is a little bit longer.</p>
            <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
        </div>
    </div>

</body>

</html>