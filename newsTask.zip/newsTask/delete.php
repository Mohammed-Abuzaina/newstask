<?php 
include 'config.php';
include 'include/function.php';
$id =$_GET['id'];
delete('category',$id,' cate_id=?');
header('location:category.php');