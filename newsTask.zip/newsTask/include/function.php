<?php
//fetech data in databeas
function fetchData($table){
    // $GLOBALS['conn'];employees
    global $conn;
    $stmt = $conn->prepare("SELECT * FROM $table");
    $stmt->execute();
    $data = $stmt->fetchAll();
    return $data;
}
function insert($table,$name){
    global $conn;
     $stmt = $conn->prepare("INSERT INTO $table (name_category) VALUES (?) ");
     $stmt->execute(array($name));

}
function insertarticle($table,$title,$img,$des){
    global $conn;
    $stmt = $conn->prepare('INSERT INTO '.$table.'(title,image,description,) VALUES (?,?,?) ');
    $stmt->execute(array($title,$img,$des));

}
function delete($table,$id,$condtion){
    global $conn;
 $stmt=$conn->prepare("DELETE FROM $table WHERE $condtion");
 $stmt->execute(array($id));
}

?>
